# Propwash FPV – Brand Kit

Everything you need to make videos, thumbnails, streams, server art or articles about **Propwash FPV**, the FPV drone simulator mod for Minecraft.

## Name
- Write **Propwash FPV** (or just **Propwash** once it's clear). Not "PropWash", "Prop Wash" or "Propwash mod FPV".
- Made by **lardtom**.
- Official add-ons: *Just More Parts*, *Propwash: Mob Defense*, *Propwash: Camera Drones*.

## Logo (`logo/`)
- `propwash-logo-1024.png` … `-32.png`: the logo with transparent background, rounded corners included.
- `preview-on-dark.png` / `preview-on-light.png` show it on both kinds of background.
- Please **don't** stretch, recolor, crop, rotate, add effects to or redraw the logo, and don't place it on busy backgrounds where it gets lost. Scaling is fine.
- Leave some free space around it, at least 1/4 of its width.

## Colors (`colors/`)
| Name | Hex | Use |
|---|---|---|
| Propwash Yellow | `#FFBB00` | primary accent: highlights, key words, buttons |
| Yellow Light / Dark | `#FFCB3D` / `#D99F00` | variants of the accent |
| Deep Black / Background / Panel | `#141414` / `#1A1A1A` / `#2B2B2B` | backgrounds |
| White / Muted | `#FFFFFF` / `#B0B0B0` | text / secondary text |
| Gate Green / Warning Red | `#5BC85B` / `#F2665E` | racing / warnings |

Dark background, white text, **one** yellow accent – that's the Propwash look. Also as `propwash-colors.css` and `.json`.

## Fonts (`fonts/`)
- **Barlow Condensed** – headlines: *Black Italic* (900) for titles and thumbnails, *ExtraBold Italic* (800) for subtitles, *Bold/SemiBold* for body text.
- **JetBrains Mono** – OSD-style lines (like the in-game drone OSD).
- Both are free under the SIL Open Font License 1.1 (`OFL.txt` next to each font) – you can use them in any project, also commercial.
- Style tip: titles in CAPS, Barlow Condensed Black Italic, white with a soft shadow, one word in Propwash Yellow.

## Images (`images/`)
Key art (1200×630) and in-game shots you can use in thumbnails and articles. Your own footage is always welcome – that's what Propwash is made for.

## Links
- Website: https://propwashfpv.com
- Modrinth: https://modrinth.com/mod/propwash-fpv
- CurseForge: https://www.curseforge.com/minecraft/mc-mods/propwash-fpv
- Discord: https://discord.gg/bNhkSXYSgZ
- Community server (Java, Propwash installed): `mc.propwashfpv.com`

## Usage
You may use everything in this kit to create content **about** Propwash FPV – videos, streams, thumbnails, server promotion, articles, mod lists. Please don't use it in a way that suggests your project is official or endorsed by Propwash unless it is, and don't sell merchandise with the logo. Questions: ask on Discord.

Propwash FPV is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.
